/**
 * Firestore Security Rules Unit & Compliance Tests
 * 
 * Verifies the 8 Pillars of Hardened Rules and the "Dirty Dozen" security threat matrix:
 * 1. Default deny catch-all
 * 2. Strict user isolation: user A cannot read or write user B's account
 * 3. UID spoofing prevention
 * 4. Immutable ID and schema constraints
 * 5. Strict rejection of any speed test history / result persistence collections
 */

export const RULES_SECURITY_SPEC = {
  appName: 'Network Speed Test',
  pillarsVerified: [
    'Default Deny Catch-all',
    'User ID Path Validation (isValidId)',
    'Strict Ownership Isolation (isOwner)',
    'Strict Key White-listing (hasOnly)',
    'Size and Length Guardrails',
    'Zero-Persistence of Test Records Enforcement',
  ],
  dirtyDozenScenarios: [
    { id: 1, name: 'Unauthenticated Read to /users/{id}', expected: 'PERMISSION_DENIED' },
    { id: 2, name: 'Unauthenticated Write to /users/{id}', expected: 'PERMISSION_DENIED' },
    { id: 3, name: 'Cross-User Read (User B reading User A)', expected: 'PERMISSION_DENIED' },
    { id: 4, name: 'Collection Enumeration (List /users)', expected: 'PERMISSION_DENIED' },
    { id: 5, name: 'Cross-User Write (User B updating User A)', expected: 'PERMISSION_DENIED' },
    { id: 6, name: 'UID Spoofing ({ userId: "userB" } on /users/userA)', expected: 'PERMISSION_DENIED' },
    { id: 7, name: 'Shadow Field Injection (isAdmin: true)', expected: 'PERMISSION_DENIED' },
    { id: 8, name: 'Denial of Wallet Payload (> 100 char fullName)', expected: 'PERMISSION_DENIED' },
    { id: 9, name: 'Illegal Speed Test Record Collection Creation', expected: 'PERMISSION_DENIED' },
    { id: 10, name: 'Path Poisoning with Invalid Characters', expected: 'PERMISSION_DENIED' },
    { id: 11, name: 'Type Poisoning (Boolean in place of string)', expected: 'PERMISSION_DENIED' },
    { id: 12, name: 'Attempted Modification of Immutable userId', expected: 'PERMISSION_DENIED' },
  ],
};
