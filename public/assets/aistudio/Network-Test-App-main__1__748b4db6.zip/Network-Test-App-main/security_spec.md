# Security Specification: Network Speed Test

## 1. Data Invariants
1. Only authenticated users can access their own account profile (`/users/{userId}`).
2. A user cannot create or modify another user's profile (`request.auth.uid == userId`).
3. Document data `userId` must match `request.auth.uid`.
4. No speed test results or test histories exist or may be created in Firestore. All other collections are rejected by default.
5. Users cannot inject arbitrary shadow fields into their profile.
6. User email in profile must be a valid string, and the user must be authenticated.

## 2. The "Dirty Dozen" Threat Payloads
1. **Unauthenticated Read**: Attempt to read `/users/user123` without auth token -> PERMISSION_DENIED.
2. **Unauthenticated Write**: Attempt to create `/users/user123` without auth token -> PERMISSION_DENIED.
3. **Cross-User Snooping**: Authenticated user B attempting `get` on `/users/userA` -> PERMISSION_DENIED.
4. **Cross-User Listing**: Authenticated user B attempting `list` on `/users` -> PERMISSION_DENIED.
5. **Cross-User Hijacking**: Authenticated user B attempting `setDoc` on `/users/userA` -> PERMISSION_DENIED.
6. **UID Spoofing**: Authenticated user A creating `/users/userA` with `{ userId: "userB", ... }` -> PERMISSION_DENIED.
7. **Shadow Field Injection**: Writing `{ userId: "userA", fullName: "Alice", email: "a@example.com", isAdmin: true, speedRecords: [...] }` -> PERMISSION_DENIED.
8. **Oversized String / DoW Attack**: Writing 20MB payload in `fullName` -> PERMISSION_DENIED.
9. **Illegal Collection Creation (Test History Prohibited)**: Attempting write to `/speedTests/test1` or `/users/userA/tests/t1` -> PERMISSION_DENIED.
10. **Malicious Document ID (ID Poisoning)**: Document path containing control characters or junk characters `/users/%2F%00junk` -> PERMISSION_DENIED.
11. **Type Poisoning**: Sending `fullName: 12345` or `email: false` -> PERMISSION_DENIED.
12. **Immutable Field Modification**: Attempting to alter `userId` during profile update -> PERMISSION_DENIED.
