import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dispatchSpeedTestRoute } from './src/server/speedTestApi';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware for Speed Test API
app.use('/api/speedtest', (req, res, next) => {
  const handled = dispatchSpeedTestRoute(req, res);
  if (!handled) {
    next();
  }
});

// Serve frontend static build
const distPath = path.resolve(__dirname, 'dist');
app.use(express.static(distPath));

// SPA Fallback
app.get('*', (_req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Network Speed Test Server running on port ${PORT}`);
});
