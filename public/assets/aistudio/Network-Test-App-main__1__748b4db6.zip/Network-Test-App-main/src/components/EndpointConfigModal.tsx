import React from 'react';
import { TEST_ENDPOINTS, TestEndpoint } from '../config/endpoints';
import { X, Server, Code, Info, Globe2 } from 'lucide-react';

interface EndpointConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedEndpoint: TestEndpoint;
}

export const EndpointConfigModal: React.FC<EndpointConfigModalProps> = ({
  isOpen,
  onClose,
  selectedEndpoint,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 text-cyan-400 flex items-center justify-center border border-cyan-800/60">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">LibreSpeed Endpoint Architecture</h3>
              <p className="text-xs text-slate-400">Inspecting src/config/endpoints.ts configuration</p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-200 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong>LibreSpeed Contract:</strong> All tests run against external endpoints using:
              <ul className="mt-1 space-y-0.5 list-disc list-inside text-cyan-300 font-mono text-[11px]">
                <li>Ping / Jitter: GET /empty.php</li>
                <li>Download: GET /garbage.php?ckSize=15</li>
                <li>Upload: POST /empty.php</li>
              </ul>
              Zero simulated latency or mock data. Tests require reachable servers with CORS enabled.
            </div>
          </div>

          {/* List of 4 endpoints and their configured URLs */}
          <div className="space-y-3">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Configured Endpoints (Exactly 4 Locations)
            </span>
            <div className="space-y-2.5">
              {TEST_ENDPOINTS.map((ep) => (
                <div
                  key={ep.id}
                  className={`p-3.5 rounded-xl border text-xs ${
                    ep.id === selectedEndpoint.id
                      ? 'bg-slate-800/80 border-cyan-500/60 shadow-lg shadow-cyan-500/5'
                      : 'bg-slate-950/60 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Server className={`w-3.5 h-3.5 ${ep.id === selectedEndpoint.id ? 'text-cyan-400' : 'text-slate-500'}`} />
                      <span className="font-semibold text-white">{ep.name}</span>
                      <span className="text-slate-500 font-mono">({ep.serverCode})</span>
                    </div>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                      {ep.location}
                    </span>
                  </div>

                  <div className="space-y-1 font-mono text-[11px]">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <span className="text-slate-500 w-16">Base URL:</span>
                      <span className="text-amber-300 truncate">{ep.baseUrl}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <span className="text-slate-500 w-16">Ping:</span>
                      <span className="text-slate-300 truncate">{ep.pingUrl}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <span className="text-slate-500 w-16">Download:</span>
                      <span className="text-slate-300 truncate">{ep.downloadUrl}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <span className="text-slate-500 w-16">Upload:</span>
                      <span className="text-slate-300 truncate">{ep.uploadUrl}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              onClick={onClose}
              type="button"
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
