import React from 'react';
import { TEST_ENDPOINTS, TestEndpoint } from '../config/endpoints';
import { Server, CheckCircle2, Globe2, Radio } from 'lucide-react';

interface EndpointSelectorProps {
  selectedEndpoint: TestEndpoint;
  onSelectEndpoint: (endpoint: TestEndpoint) => void;
  disabled: boolean;
}

export const EndpointSelector: React.FC<EndpointSelectorProps> = ({
  selectedEndpoint,
  onSelectEndpoint,
  disabled,
}) => {
  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h2 className="text-sm font-semibold text-slate-200 tracking-wide uppercase flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            Select Test Server Endpoint
          </h2>
          <p className="text-xs text-slate-400">
            Choose one of the four dedicated test nodes for throughput benchmarking
          </p>
        </div>

        {/* Selected endpoint highlight banner */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-cyan-950/40 border border-cyan-800/60 text-cyan-300 text-xs self-start sm:self-auto">
          <span className="text-slate-400 font-medium">Selected Test Server:</span>
          <span className="font-bold text-white bg-cyan-500/20 px-2 py-0.5 rounded border border-cyan-500/30">
            {selectedEndpoint.name}
          </span>
        </div>
      </div>

      {/* Exactly four endpoint cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {TEST_ENDPOINTS.map((endpoint) => {
          const isSelected = endpoint.id === selectedEndpoint.id;

          return (
            <button
              key={endpoint.id}
              type="button"
              disabled={disabled}
              onClick={() => onSelectEndpoint(endpoint)}
              className={`relative text-left p-4 rounded-xl border transition-all duration-200 cursor-pointer select-none group ${
                isSelected
                  ? 'bg-gradient-to-b from-cyan-950/60 to-slate-900 border-cyan-500/80 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500/50'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-850'
              } ${disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}`}
            >
              {/* Active selection badge */}
              <div className="flex items-start justify-between mb-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center border transition-colors ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400/40 text-cyan-300'
                      : 'bg-slate-800/80 border-slate-700 text-slate-400 group-hover:text-slate-200 group-hover:border-slate-600'
                  }`}
                >
                  <Server className="w-4 h-4" />
                </div>

                {isSelected ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/30">
                    <CheckCircle2 className="w-3 h-3" />
                    Active
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-slate-500 group-hover:text-slate-400">
                    {endpoint.serverCode}
                  </span>
                )}
              </div>

              {/* Endpoint name & location */}
              <div className="mb-1">
                <h3 className={`text-sm font-bold tracking-tight ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                  {endpoint.name}
                </h3>
                <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                  <Globe2 className="w-3 h-3 text-slate-500" />
                  {endpoint.location}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">{endpoint.description}</span>
                <span className={`font-mono text-[10px] px-1.5 py-0.5 rounded ${
                  isSelected ? 'bg-cyan-900/40 text-cyan-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  {endpoint.countryCode}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
