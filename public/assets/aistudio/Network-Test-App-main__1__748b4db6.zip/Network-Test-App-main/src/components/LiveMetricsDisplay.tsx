import React from 'react';
import { LiveMetrics } from '../services/speedTestEngine';
import { Activity, ArrowDown, ArrowUp, Wifi, AlertTriangle } from 'lucide-react';

interface LiveMetricsDisplayProps {
  metrics: LiveMetrics;
}

export const LiveMetricsDisplay: React.FC<LiveMetricsDisplayProps> = ({ metrics }) => {
  const {
    stage,
    pingMs,
    jitterMs,
    currentDownloadMbps,
    currentUploadMbps,
    pingProgress,
    jitterProgress,
    downloadProgress,
    uploadProgress,
  } = metrics;

  const isPingHigh = pingMs !== null && pingMs > 110;
  const isJitterHigh = jitterMs !== null && jitterMs > 110;
  const isDownloadLow = currentDownloadMbps !== null && currentDownloadMbps < 25 && (stage === 'upload' || stage === 'complete');
  const isUploadLow = currentUploadMbps !== null && currentUploadMbps < 25 && stage === 'complete';

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 w-full">
      {/* 1. Ping Progress Card */}
      <div className={`p-4 rounded-xl border transition-all ${
        isPingHigh
          ? 'bg-rose-950/20 border-rose-500/50 ring-1 ring-rose-500/30'
          : stage === 'ping'
          ? 'bg-amber-950/20 border-amber-500/40 ring-1 ring-amber-500/30'
          : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Wifi className={`w-3.5 h-3.5 ${isPingHigh ? 'text-rose-400' : stage === 'ping' ? 'text-amber-400 animate-pulse' : 'text-slate-500'}`} />
            Latency (Ping)
          </span>
          {stage === 'error' ? (
            <span className="font-mono text-xs text-rose-400">Failed</span>
          ) : isPingHigh ? (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-300 bg-rose-500/20 px-1.5 py-0.5 rounded border border-rose-500/30">
              <AlertTriangle className="w-2.5 h-2.5" /> &gt;110 ms
            </span>
          ) : (
            <span className="font-mono text-xs text-slate-400">
              {stage === 'ping' ? `${pingProgress}%` : pingMs !== null ? 'Done' : 'Pending'}
            </span>
          )}
        </div>
        <div className={`text-xl font-bold font-mono mb-2 ${isPingHigh ? 'text-rose-300' : 'text-white'}`}>
          {pingMs !== null ? `${pingMs.toFixed(1)} ms` : '--'}
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-150 ${isPingHigh ? 'bg-rose-400' : 'bg-amber-400'}`}
            style={{ width: `${pingProgress}%` }}
          />
        </div>
      </div>

      {/* 2. Jitter Card */}
      <div className={`p-4 rounded-xl border transition-all ${
        isJitterHigh
          ? 'bg-rose-950/20 border-rose-500/50 ring-1 ring-rose-500/30'
          : stage === 'jitter'
          ? 'bg-sky-950/20 border-sky-500/40 ring-1 ring-sky-500/30'
          : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <Activity className={`w-3.5 h-3.5 ${isJitterHigh ? 'text-rose-400' : stage === 'jitter' ? 'text-sky-400 animate-pulse' : 'text-slate-500'}`} />
            Jitter (RFC 3550)
          </span>
          {stage === 'error' ? (
            <span className="font-mono text-xs text-rose-400">Failed</span>
          ) : isJitterHigh ? (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-300 bg-rose-500/20 px-1.5 py-0.5 rounded border border-rose-500/30">
              <AlertTriangle className="w-2.5 h-2.5" /> &gt;110 ms
            </span>
          ) : (
            <span className="font-mono text-xs text-slate-400">
              {stage === 'jitter' ? `${jitterProgress}%` : jitterMs !== null ? 'Done' : 'Pending'}
            </span>
          )}
        </div>
        <div className={`text-xl font-bold font-mono mb-2 ${isJitterHigh ? 'text-rose-300' : 'text-sky-300'}`}>
          {jitterMs !== null ? `${jitterMs.toFixed(2)} ms` : '--'}
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-150 ${isJitterHigh ? 'bg-rose-400' : 'bg-sky-400'}`}
            style={{ width: `${jitterProgress}%` }}
          />
        </div>
      </div>

      {/* 3. Download Progress Card */}
      <div className={`p-4 rounded-xl border transition-all ${
        isDownloadLow
          ? 'bg-amber-950/20 border-amber-500/50 ring-1 ring-amber-500/30'
          : stage === 'download'
          ? 'bg-cyan-950/20 border-cyan-500/40 ring-1 ring-cyan-500/30'
          : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <ArrowDown className={`w-3.5 h-3.5 ${isDownloadLow ? 'text-amber-400' : stage === 'download' ? 'text-cyan-400 animate-bounce' : 'text-slate-500'}`} />
            Download
          </span>
          {stage === 'error' ? (
            <span className="font-mono text-xs text-rose-400">Failed</span>
          ) : isDownloadLow ? (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30">
              <AlertTriangle className="w-2.5 h-2.5" /> &lt;25 Mbps
            </span>
          ) : (
            <span className="font-mono text-xs text-slate-400">
              {stage === 'download' ? `${downloadProgress}%` : currentDownloadMbps !== null ? 'Done' : 'Pending'}
            </span>
          )}
        </div>
        <div className={`text-xl font-bold font-mono mb-2 ${isDownloadLow ? 'text-amber-300' : 'text-cyan-300'}`}>
          {currentDownloadMbps !== null ? `${currentDownloadMbps.toFixed(2)} Mbps` : '--'}
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-150 ${isDownloadLow ? 'bg-amber-400' : 'bg-cyan-400'}`}
            style={{ width: `${downloadProgress}%` }}
          />
        </div>
      </div>

      {/* 4. Upload Progress Card */}
      <div className={`p-4 rounded-xl border transition-all ${
        isUploadLow
          ? 'bg-amber-950/20 border-amber-500/50 ring-1 ring-amber-500/30'
          : stage === 'upload'
          ? 'bg-indigo-950/20 border-indigo-500/40 ring-1 ring-indigo-500/30'
          : 'bg-slate-900/60 border-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-slate-400 flex items-center gap-1.5">
            <ArrowUp className={`w-3.5 h-3.5 ${isUploadLow ? 'text-amber-400' : stage === 'upload' ? 'text-indigo-400 animate-bounce' : 'text-slate-500'}`} />
            Upload
          </span>
          {stage === 'error' ? (
            <span className="font-mono text-xs text-rose-400">Failed</span>
          ) : isUploadLow ? (
            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded border border-amber-500/30">
              <AlertTriangle className="w-2.5 h-2.5" /> &lt;25 Mbps
            </span>
          ) : (
            <span className="font-mono text-xs text-slate-400">
              {stage === 'upload' ? `${uploadProgress}%` : currentUploadMbps !== null ? 'Done' : 'Pending'}
            </span>
          )}
        </div>
        <div className={`text-xl font-bold font-mono mb-2 ${isUploadLow ? 'text-amber-300' : 'text-indigo-300'}`}>
          {currentUploadMbps !== null ? `${currentUploadMbps.toFixed(2)} Mbps` : '--'}
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-150 ${isUploadLow ? 'bg-amber-400' : 'bg-indigo-400'}`}
            style={{ width: `${uploadProgress}%` }}
          />
        </div>
      </div>
    </div>
  );
};
