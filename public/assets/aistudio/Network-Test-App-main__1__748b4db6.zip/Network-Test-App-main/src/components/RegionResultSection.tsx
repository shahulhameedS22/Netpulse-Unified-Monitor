import React from 'react';
import { TestEndpoint } from '../config/endpoints';
import { LiveMetrics, SpeedTestResult, TestStage } from '../services/speedTestEngine';
import {
  ArrowDown,
  ArrowUp,
  Wifi,
  Activity,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  ShieldCheck,
} from 'lucide-react';

export type RegionStatus = 'waiting' | 'testing' | 'completed' | 'failed';

export interface RegionState {
  endpoint: TestEndpoint;
  status: RegionStatus;
  stage: TestStage;
  liveMetrics: LiveMetrics | null;
  result: SpeedTestResult | null;
  errorMessage: string | null;
}

interface RegionResultSectionProps {
  region: RegionState;
  index: number;
  isActive: boolean;
}

export const RegionResultSection: React.FC<RegionResultSectionProps> = ({
  region,
  index,
  isActive,
}) => {
  const { endpoint, status, stage, liveMetrics, result, errorMessage } = region;

  // Determine stage label during testing
  const getStageDisplay = () => {
    switch (stage) {
      case 'ping':
        return `Testing Ping (${liveMetrics?.pingProgress || 0}%)`;
      case 'jitter':
        return `Testing Jitter (${liveMetrics?.jitterProgress || 0}%)`;
      case 'download':
        return `Testing Download (${liveMetrics?.downloadProgress || 0}%)`;
      case 'upload':
        return `Testing Upload (${liveMetrics?.uploadProgress || 0}%)`;
      default:
        return 'Connecting...';
    }
  };

  // Performance alert checks for completed results:
  // - Download < 25 Mbps
  // - Upload < 25 Mbps
  // - Ping > 110 ms
  // - Jitter > 110 ms
  const isDownloadLow = result !== null && result.downloadMbps < 25;
  const isUploadLow = result !== null && result.uploadMbps < 25;
  const isPingHigh = result !== null && result.pingMs > 110;
  const isJitterHigh = result !== null && result.jitterMs > 110;
  const hasAlerts = isDownloadLow || isUploadLow || isPingHigh || isJitterHigh;

  const alertsCount = [isDownloadLow, isUploadLow, isPingHigh, isJitterHigh].filter(Boolean).length;

  return (
    <section
      id={`region-${endpoint.serverCode.toLowerCase()}`}
      className={`rounded-xl transition-all duration-300 relative overflow-hidden backdrop-blur-xl border ${
        isActive
          ? 'bg-slate-900/90 border-cyan-500/60 ring-2 ring-cyan-500/30 shadow-xl shadow-cyan-500/10'
          : status === 'completed'
          ? 'bg-slate-900/70 border-slate-800/90 shadow-md'
          : status === 'failed'
          ? 'bg-slate-900/60 border-rose-900/40 shadow-md'
          : 'bg-slate-900/40 border-slate-800/60 opacity-90'
      } p-3.5 sm:p-4`}
    >
      {/* Top Banner & Header (Compact single-line on desktop) */}
      <div className="flex items-center justify-between gap-3 pb-2.5 border-b border-slate-800/80">
        <div className="flex items-center gap-2.5 min-w-0">
          {/* Compact Region Number Badge */}
          <div
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs shrink-0 border transition-colors ${
              isActive
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                : status === 'completed'
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : status === 'failed'
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-slate-800/80 text-slate-400 border-slate-700/80'
            }`}
          >
            0{index + 1}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap leading-tight">
              <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                {endpoint.serverCode}
              </h3>
              <span className="text-slate-500 text-xs">•</span>
              <span className="text-xs sm:text-sm font-semibold text-slate-200 truncate">
                {endpoint.name}
              </span>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700">
                {endpoint.location}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono truncate max-w-[200px] sm:max-w-xs mt-0.5">
              <span className="text-slate-500">Host: </span>
              <span className="text-slate-300">{endpoint.baseUrl}</span>
            </div>
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-1.5 shrink-0">
          {status === 'waiting' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-slate-800/80 text-slate-400 border border-slate-700">
              <Clock className="w-3 h-3 text-slate-400" />
              Waiting
            </span>
          )}

          {status === 'testing' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 animate-pulse shadow-sm shadow-cyan-500/20">
              <Activity className="w-3 h-3 text-cyan-400 animate-spin" />
              {getStageDisplay()}
            </span>
          )}

          {status === 'completed' && (
            <div className="flex items-center gap-1.5">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Completed
              </span>
              {hasAlerts && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  <AlertTriangle className="w-2.5 h-2.5 text-amber-400" />
                  {alertsCount} Alert{alertsCount > 1 ? 's' : ''}
                </span>
              )}
            </div>
          )}

          {status === 'failed' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
              <XCircle className="w-3 h-3 text-rose-400" />
              Failed
            </span>
          )}
        </div>
      </div>

      {/* In-Test Progress Bar */}
      {status === 'testing' && (
        <div className="mt-2.5">
          <div className="flex justify-between text-[11px] mb-1">
            <span className="text-cyan-400 font-medium flex items-center gap-1">
              <Activity className="w-2.5 h-2.5 text-cyan-400 animate-pulse" />
              {getStageDisplay()}
            </span>
            <span className="font-mono text-cyan-300 font-bold">
              {liveMetrics?.progressPercent || 0}%
            </span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 transition-all duration-200"
              style={{ width: `${liveMetrics?.progressPercent || 0}%` }}
            />
          </div>
        </div>
      )}

      {/* Compact Failure Banner if Region Failed */}
      {status === 'failed' && (
        <div className="mt-2.5 p-2.5 rounded-lg bg-rose-950/25 border border-rose-500/30 text-rose-200 text-xs flex flex-col gap-1.5">
          <div className="flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
            <div className="text-[11px] leading-tight">
              <span className="font-semibold text-rose-300">
                Connection to {endpoint.serverCode} blocked:{' '}
              </span>
              <span className="text-rose-200/90">
                {errorMessage ||
                  'Direct browser connection blocked. CORS headers not present or TLS blocked on port 8443.'}
              </span>
            </div>
          </div>
          <div className="px-2 py-1 rounded bg-slate-950/70 text-[10px] font-mono text-slate-400 truncate">
            Target: <span className="text-amber-300">{endpoint.pingUrl}</span> • Zero simulated data
          </div>
        </div>
      )}

      {/* Compact Alert Banner if Region Completed with Quality Alerts */}
      {status === 'completed' && hasAlerts && (
        <div className="mt-2.5 p-2 rounded-lg bg-amber-950/25 border border-amber-500/30 text-amber-200 text-[11px] flex items-center gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <div className="truncate">
            <span className="font-bold text-amber-300">Alert: </span>
            <span>
              Threshold breached (
              {[
                isDownloadLow ? 'Down <25 Mbps' : null,
                isUploadLow ? 'Up <25 Mbps' : null,
                isPingHigh ? 'Ping >110ms' : null,
                isJitterHigh ? 'Jitter >110ms' : null,
              ]
                .filter(Boolean)
                .join(', ')}
              )
            </span>
          </div>
        </div>
      )}

      {/* Four Metrics Cards (Download, Upload, Ping, Jitter) in Compact 4-Column Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2.5">
        {/* 1. Download Card */}
        <div
          className={`p-2.5 rounded-lg border transition-all ${
            isDownloadLow
              ? 'bg-amber-950/20 border-amber-500/50 ring-1 ring-amber-500/30'
              : status === 'completed'
              ? 'bg-slate-950/60 border-cyan-500/30'
              : status === 'testing' && stage === 'download'
              ? 'bg-cyan-950/20 border-cyan-500/50 ring-1 ring-cyan-500/30'
              : 'bg-slate-950/40 border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 truncate">
              <ArrowDown
                className={`w-3 h-3 shrink-0 ${
                  isDownloadLow
                    ? 'text-amber-400'
                    : status === 'testing' && stage === 'download'
                    ? 'text-cyan-400 animate-bounce'
                    : 'text-cyan-400'
                }`}
              />
              Download
            </span>
            {isDownloadLow ? (
              <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-amber-300 bg-amber-500/20 px-1 py-0.5 rounded border border-amber-500/30 shrink-0">
                <AlertTriangle className="w-2 h-2" /> &lt;25
              </span>
            ) : status === 'completed' ? (
              <span className="text-[9px] font-mono text-emerald-400 font-semibold shrink-0">Done</span>
            ) : status === 'testing' && stage === 'download' ? (
              <span className="text-[9px] font-mono text-cyan-300 font-semibold shrink-0">Live</span>
            ) : (
              <span className="text-[9px] font-mono text-slate-500 shrink-0">
                {status === 'failed' ? 'Failed' : 'Pending'}
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1">
            <span
              className={`text-lg sm:text-xl font-extrabold font-mono tracking-tight ${
                isDownloadLow
                  ? 'text-amber-300'
                  : result
                  ? 'text-white'
                  : liveMetrics?.currentDownloadMbps
                  ? 'text-cyan-300'
                  : 'text-slate-600'
              }`}
            >
              {result !== null
                ? result.downloadMbps.toFixed(2)
                : liveMetrics?.currentDownloadMbps !== null && liveMetrics?.currentDownloadMbps !== undefined
                ? liveMetrics.currentDownloadMbps.toFixed(2)
                : '--'}
            </span>
            <span className="text-[10px] font-mono text-slate-500">Mbps</span>
          </div>
          <p className="text-[10px] text-slate-500 truncate mt-0.5">Multi-stream</p>
        </div>

        {/* 2. Upload Card */}
        <div
          className={`p-2.5 rounded-lg border transition-all ${
            isUploadLow
              ? 'bg-amber-950/20 border-amber-500/50 ring-1 ring-amber-500/30'
              : status === 'completed'
              ? 'bg-slate-950/60 border-indigo-500/30'
              : status === 'testing' && stage === 'upload'
              ? 'bg-indigo-950/20 border-indigo-500/50 ring-1 ring-indigo-500/30'
              : 'bg-slate-950/40 border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 truncate">
              <ArrowUp
                className={`w-3 h-3 shrink-0 ${
                  isUploadLow
                    ? 'text-amber-400'
                    : status === 'testing' && stage === 'upload'
                    ? 'text-indigo-400 animate-bounce'
                    : 'text-indigo-400'
                }`}
              />
              Upload
            </span>
            {isUploadLow ? (
              <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-amber-300 bg-amber-500/20 px-1 py-0.5 rounded border border-amber-500/30 shrink-0">
                <AlertTriangle className="w-2 h-2" /> &lt;25
              </span>
            ) : status === 'completed' ? (
              <span className="text-[9px] font-mono text-emerald-400 font-semibold shrink-0">Done</span>
            ) : status === 'testing' && stage === 'upload' ? (
              <span className="text-[9px] font-mono text-indigo-300 font-semibold shrink-0">Live</span>
            ) : (
              <span className="text-[9px] font-mono text-slate-500 shrink-0">
                {status === 'failed' ? 'Failed' : 'Pending'}
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1">
            <span
              className={`text-lg sm:text-xl font-extrabold font-mono tracking-tight ${
                isUploadLow
                  ? 'text-amber-300'
                  : result
                  ? 'text-white'
                  : liveMetrics?.currentUploadMbps
                  ? 'text-indigo-300'
                  : 'text-slate-600'
              }`}
            >
              {result !== null
                ? result.uploadMbps.toFixed(2)
                : liveMetrics?.currentUploadMbps !== null && liveMetrics?.currentUploadMbps !== undefined
                ? liveMetrics.currentUploadMbps.toFixed(2)
                : '--'}
            </span>
            <span className="text-[10px] font-mono text-slate-500">Mbps</span>
          </div>
          <p className="text-[10px] text-slate-500 truncate mt-0.5">Binary POST</p>
        </div>

        {/* 3. Latency (Ping) Card */}
        <div
          className={`p-2.5 rounded-lg border transition-all ${
            isPingHigh
              ? 'bg-rose-950/20 border-rose-500/50 ring-1 ring-rose-500/30'
              : status === 'completed'
              ? 'bg-slate-950/60 border-amber-500/30'
              : status === 'testing' && stage === 'ping'
              ? 'bg-amber-950/20 border-amber-500/50 ring-1 ring-amber-500/30'
              : 'bg-slate-950/40 border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 truncate">
              <Wifi
                className={`w-3 h-3 shrink-0 ${
                  isPingHigh
                    ? 'text-rose-400'
                    : status === 'testing' && stage === 'ping'
                    ? 'text-amber-400 animate-pulse'
                    : 'text-amber-400'
                }`}
              />
              Ping
            </span>
            {isPingHigh ? (
              <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-rose-300 bg-rose-500/20 px-1 py-0.5 rounded border border-rose-500/30 shrink-0">
                <AlertTriangle className="w-2 h-2" /> &gt;110
              </span>
            ) : status === 'completed' ? (
              <span className="text-[9px] font-mono text-emerald-400 font-semibold shrink-0">Done</span>
            ) : status === 'testing' && stage === 'ping' ? (
              <span className="text-[9px] font-mono text-amber-300 font-semibold shrink-0">Probe</span>
            ) : (
              <span className="text-[9px] font-mono text-slate-500 shrink-0">
                {status === 'failed' ? 'Failed' : 'Pending'}
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1">
            <span
              className={`text-lg sm:text-xl font-extrabold font-mono tracking-tight ${
                isPingHigh
                  ? 'text-rose-300'
                  : result
                  ? 'text-white'
                  : liveMetrics?.pingMs
                  ? 'text-amber-300'
                  : 'text-slate-600'
              }`}
            >
              {result !== null
                ? result.pingMs.toFixed(1)
                : liveMetrics?.pingMs !== null && liveMetrics?.pingMs !== undefined
                ? liveMetrics.pingMs.toFixed(1)
                : '--'}
            </span>
            <span className="text-[10px] font-mono text-slate-500">ms</span>
          </div>
          <p className="text-[10px] text-slate-500 truncate mt-0.5">10 probes</p>
        </div>

        {/* 4. Jitter Card */}
        <div
          className={`p-2.5 rounded-lg border transition-all ${
            isJitterHigh
              ? 'bg-rose-950/20 border-rose-500/50 ring-1 ring-rose-500/30'
              : status === 'completed'
              ? 'bg-slate-950/60 border-sky-500/30'
              : status === 'testing' && stage === 'jitter'
              ? 'bg-sky-950/20 border-sky-500/50 ring-1 ring-sky-500/30'
              : 'bg-slate-950/40 border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 truncate">
              <Activity
                className={`w-3 h-3 shrink-0 ${
                  isJitterHigh
                    ? 'text-rose-400'
                    : status === 'testing' && stage === 'jitter'
                    ? 'text-sky-400 animate-pulse'
                    : 'text-sky-400'
                }`}
              />
              Jitter
            </span>
            {isJitterHigh ? (
              <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-rose-300 bg-rose-500/20 px-1 py-0.5 rounded border border-rose-500/30 shrink-0">
                <AlertTriangle className="w-2 h-2" /> &gt;110
              </span>
            ) : status === 'completed' ? (
              <span className="text-[9px] font-mono text-emerald-400 font-semibold shrink-0">Done</span>
            ) : status === 'testing' && stage === 'jitter' ? (
              <span className="text-[9px] font-mono text-sky-300 font-semibold shrink-0">Probe</span>
            ) : (
              <span className="text-[9px] font-mono text-slate-500 shrink-0">
                {status === 'failed' ? 'Failed' : 'Pending'}
              </span>
            )}
          </div>
          <div className="flex items-baseline gap-1">
            <span
              className={`text-lg sm:text-xl font-extrabold font-mono tracking-tight ${
                isJitterHigh
                  ? 'text-rose-300'
                  : result
                  ? 'text-white'
                  : liveMetrics?.jitterMs
                  ? 'text-sky-300'
                  : 'text-slate-600'
              }`}
            >
              {result !== null
                ? result.jitterMs.toFixed(2)
                : liveMetrics?.jitterMs !== null && liveMetrics?.jitterMs !== undefined
                ? liveMetrics.jitterMs.toFixed(2)
                : '--'}
            </span>
            <span className="text-[10px] font-mono text-slate-500">ms</span>
          </div>
          <p className="text-[10px] text-slate-500 truncate mt-0.5">RFC 3550</p>
        </div>
      </div>

      {/* Footer Details (Compact single-line) */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/70 flex items-center justify-between text-[10px] text-slate-500 font-mono">
        <div className="truncate">
          <span>Server: <strong className="text-slate-400">{endpoint.serverCode}</strong></span>
          <span className="mx-1">•</span>
          <span className="text-slate-400 truncate">{endpoint.description}</span>
        </div>
        <div className="flex items-center gap-1 shrink-0 ml-2">
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
          <span className="hidden sm:inline">Direct browser • Zero proxy</span>
        </div>
      </div>
    </section>
  );
};
