import React from 'react';
import { SpeedTestResult } from '../services/speedTestEngine';
import { ArrowDown, ArrowUp, Wifi, Activity, RotateCcw, Server, ShieldCheck, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface ResultsDisplayProps {
  result: SpeedTestResult;
  onTestAgain: () => void;
}

interface PerformanceAlert {
  metric: 'download' | 'upload' | 'ping' | 'jitter';
  label: string;
  currentValue: string;
  threshold: string;
  description: string;
}

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, onTestAgain }) => {
  // Check the alert criteria specified by user:
  // - Download speed < 25 Mbps
  // - Upload speed < 25 Mbps
  // - Ping > 110 ms
  // - Jitter > 110 ms
  const isDownloadLow = result.downloadMbps < 25;
  const isUploadLow = result.uploadMbps < 25;
  const isPingHigh = result.pingMs > 110;
  const isJitterHigh = result.jitterMs > 110;

  const alerts: PerformanceAlert[] = [];
  if (isDownloadLow) {
    alerts.push({
      metric: 'download',
      label: 'Low Download Speed',
      currentValue: `${result.downloadMbps.toFixed(2)} Mbps`,
      threshold: '< 25.00 Mbps',
      description: 'Download throughput dropped below the minimum 25 Mbps benchmark.',
    });
  }
  if (isUploadLow) {
    alerts.push({
      metric: 'upload',
      label: 'Low Upload Speed',
      currentValue: `${result.uploadMbps.toFixed(2)} Mbps`,
      threshold: '< 25.00 Mbps',
      description: 'Upload throughput dropped below the minimum 25 Mbps benchmark.',
    });
  }
  if (isPingHigh) {
    alerts.push({
      metric: 'ping',
      label: 'High Latency (Ping)',
      currentValue: `${result.pingMs.toFixed(2)} ms`,
      threshold: '> 110.00 ms',
      description: 'Round-trip latency exceeded the maximum 110 ms quality threshold.',
    });
  }
  if (isJitterHigh) {
    alerts.push({
      metric: 'jitter',
      label: 'High Packet Jitter',
      currentValue: `${result.jitterMs.toFixed(2)} ms`,
      threshold: '> 110.00 ms',
      description: 'Packet delay variation exceeded the maximum 110 ms stability threshold.',
    });
  }

  const hasAlerts = alerts.length > 0;

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Results Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              Speed Test Results
            </h2>
            {hasAlerts ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Performance Alert ({alerts.length})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Optimal Quality
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Measured against {result.endpoint.name} at {result.timestamp}
          </p>
        </div>

        <button
          onClick={onTestAgain}
          type="button"
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 transition-all duration-200 cursor-pointer self-start sm:self-auto hover:scale-[1.02] active:scale-[0.98]"
        >
          <RotateCcw className="w-4 h-4" />
          Test Again
        </button>
      </div>

      {/* Prominent Warning Alert Message Banner */}
      {hasAlerts && (
        <div className="my-6 p-4 sm:p-5 rounded-xl bg-amber-950/40 border border-amber-500/50 text-amber-200 shadow-xl shadow-amber-950/20 animate-fade-in">
          <div className="flex items-start gap-3.5">
            <div className="w-9 h-9 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5 animate-pulse" />
            </div>
            <div className="flex-1">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <h3 className="text-sm font-bold text-amber-300 tracking-wide uppercase">
                  Network Quality Alert Warning
                </h3>
                <span className="text-[11px] font-mono font-semibold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 self-start sm:self-auto">
                  {alerts.length} Metric{alerts.length > 1 ? 's' : ''} Breached Thresholds
                </span>
              </div>
              <p className="text-xs text-amber-200/90 mt-1">
                Connection to <strong>{result.endpoint.name}</strong> experienced suboptimal performance. The following metrics breached network quality thresholds:
              </p>
              <ul className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                {alerts.map((alert, idx) => (
                  <li
                    key={idx}
                    className="p-2.5 rounded-lg bg-slate-900/80 border border-amber-500/30 flex items-start gap-2 text-amber-100"
                  >
                    <span className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 shrink-0"></span>
                    <div>
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <span>{alert.label}:</span>
                        <span className="text-amber-300 font-mono font-bold">{alert.currentValue}</span>
                      </div>
                      <div className="text-[11px] text-amber-400/80 font-mono">
                        Rule: {alert.threshold}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{alert.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Prominent Results Grid with Metric-Specific Warning Badges */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 my-6">
        {/* 1. Download Speed */}
        <div
          className={`rounded-xl p-5 relative overflow-hidden transition-all ${
            isDownloadLow
              ? 'bg-amber-950/20 border-2 border-amber-500/60 shadow-lg shadow-amber-950/20 ring-1 ring-amber-500/40'
              : 'bg-slate-950/70 border border-cyan-500/30 hover:border-cyan-500/50'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <ArrowDown className={`w-4 h-4 ${isDownloadLow ? 'text-amber-400' : 'text-cyan-400'}`} />
              Download Speed
            </span>
            {isDownloadLow ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40 animate-pulse">
                <AlertTriangle className="w-3 h-3" />
                Low (&lt;25 Mbps)
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-4xl font-extrabold font-mono tracking-tight ${isDownloadLow ? 'text-amber-300' : 'text-white'}`}>
              {result.downloadMbps.toFixed(2)}
            </span>
            <span className={`text-sm font-semibold font-mono ${isDownloadLow ? 'text-amber-400' : 'text-cyan-400'}`}>
              Mbps
            </span>
          </div>
          <p className={`text-[11px] mt-2 ${isDownloadLow ? 'text-amber-400/90 font-medium' : 'text-slate-500'}`}>
            {isDownloadLow ? '⚠️ Low speed alert: Below 25 Mbps' : 'Multi-stream throughput'}
          </p>
        </div>

        {/* 2. Upload Speed */}
        <div
          className={`rounded-xl p-5 relative overflow-hidden transition-all ${
            isUploadLow
              ? 'bg-amber-950/20 border-2 border-amber-500/60 shadow-lg shadow-amber-950/20 ring-1 ring-amber-500/40'
              : 'bg-slate-950/70 border border-indigo-500/30 hover:border-indigo-500/50'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <ArrowUp className={`w-4 h-4 ${isUploadLow ? 'text-amber-400' : 'text-indigo-400'}`} />
              Upload Speed
            </span>
            {isUploadLow ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40 animate-pulse">
                <AlertTriangle className="w-3 h-3" />
                Low (&lt;25 Mbps)
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-4xl font-extrabold font-mono tracking-tight ${isUploadLow ? 'text-amber-300' : 'text-white'}`}>
              {result.uploadMbps.toFixed(2)}
            </span>
            <span className={`text-sm font-semibold font-mono ${isUploadLow ? 'text-amber-400' : 'text-indigo-400'}`}>
              Mbps
            </span>
          </div>
          <p className={`text-[11px] mt-2 ${isUploadLow ? 'text-amber-400/90 font-medium' : 'text-slate-500'}`}>
            {isUploadLow ? '⚠️ Low speed alert: Below 25 Mbps' : 'Binary payload throughput'}
          </p>
        </div>

        {/* 3. Ping */}
        <div
          className={`rounded-xl p-5 relative overflow-hidden transition-all ${
            isPingHigh
              ? 'bg-rose-950/20 border-2 border-rose-500/60 shadow-lg shadow-rose-950/20 ring-1 ring-rose-500/40'
              : 'bg-slate-950/70 border border-amber-500/30 hover:border-amber-500/50'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Wifi className={`w-4 h-4 ${isPingHigh ? 'text-rose-400' : 'text-amber-400'}`} />
              Ping
            </span>
            {isPingHigh ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded-full border border-rose-500/40 animate-pulse">
                <AlertTriangle className="w-3 h-3" />
                High (&gt;110 ms)
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-4xl font-extrabold font-mono tracking-tight ${isPingHigh ? 'text-rose-300' : 'text-white'}`}>
              {result.pingMs.toFixed(2)}
            </span>
            <span className={`text-sm font-semibold font-mono ${isPingHigh ? 'text-rose-400' : 'text-amber-400'}`}>
              ms
            </span>
          </div>
          <p className={`text-[11px] mt-2 ${isPingHigh ? 'text-rose-400/90 font-medium' : 'text-slate-500'}`}>
            {isPingHigh ? '⚠️ High latency alert: Above 110 ms' : 'Baseline network round-trip'}
          </p>
        </div>

        {/* 4. Jitter */}
        <div
          className={`rounded-xl p-5 relative overflow-hidden transition-all ${
            isJitterHigh
              ? 'bg-rose-950/20 border-2 border-rose-500/60 shadow-lg shadow-rose-950/20 ring-1 ring-rose-500/40'
              : 'bg-slate-950/70 border border-sky-500/30 hover:border-sky-500/50'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Activity className={`w-4 h-4 ${isJitterHigh ? 'text-rose-400' : 'text-sky-400'}`} />
              Jitter
            </span>
            {isJitterHigh ? (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded-full border border-rose-500/40 animate-pulse">
                <AlertTriangle className="w-3 h-3" />
                High (&gt;110 ms)
              </span>
            ) : (
              <span className="w-2 h-2 rounded-full bg-sky-400"></span>
            )}
          </div>
          <div className="flex items-baseline gap-2">
            <span className={`text-4xl font-extrabold font-mono tracking-tight ${isJitterHigh ? 'text-rose-300' : 'text-white'}`}>
              {result.jitterMs.toFixed(2)}
            </span>
            <span className={`text-sm font-semibold font-mono ${isJitterHigh ? 'text-rose-400' : 'text-sky-400'}`}>
              ms
            </span>
          </div>
          <p className={`text-[11px] mt-2 ${isJitterHigh ? 'text-rose-400/90 font-medium' : 'text-slate-500'}`}>
            {isJitterHigh ? '⚠️ High jitter alert: Above 110 ms' : 'RFC 3550 delay variation'}
          </p>
        </div>
      </div>

      {/* Test Server Information Section */}
      <div className="bg-slate-950/50 border border-slate-800/80 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-950/60 border border-cyan-800/40 text-cyan-400 flex items-center justify-center">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-medium text-slate-400">Test Server</div>
            <div className="text-sm font-bold text-white flex items-center gap-2">
              <span>{result.endpoint.name}</span>
              <span className="text-xs font-normal text-slate-400">({result.endpoint.location})</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs text-slate-400 border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-800">
          <div>
            <span className="text-slate-500">Node ID: </span>
            <span className="font-mono text-slate-300">{result.endpoint.serverCode}</span>
          </div>
          <div>
            <span className="text-slate-500">Region: </span>
            <span className="font-mono text-slate-300">{result.endpoint.countryCode}</span>
          </div>
          <div className="hidden md:inline-flex items-center gap-1 text-slate-500 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            In-memory result (not logged)
          </div>
        </div>
      </div>
    </div>
  );
};
