/**
 * Centralized Network Test Endpoints Configuration
 * 
 * Configured strictly with the four real regional LibreSpeed servers:
 * 1. Sri Lanka (https://lk-dc01.trainocate.com:8443/backend/)
 * 2. Singapore (https://sg-dc01.trainocate.com:8443/backend/)
 * 3. India - INDC01 (https://in-dc01.trainocate.com:8443/backend/)
 * 4. India - INDC02 (https://in-dc02.trainocate.com:8443/backend/)
 * 
 * LibreSpeed Endpoint Contract:
 * - Ping: GET /empty.php
 * - Download: GET /garbage.php?ckSize=<size>
 * - Upload: POST /empty.php
 */

export interface TestEndpoint {
  id: string;
  name: string;
  location: string;
  countryCode: string;
  serverCode: string;
  description: string;
  baseUrl: string;
  pingUrl: string;
  downloadUrl: string;
  uploadUrl: string;
}

export const TEST_ENDPOINTS: TestEndpoint[] = [
  {
    id: 'in-dc01',
    name: 'India - INDC01',
    location: 'India (BLR_TATA) ',
    countryCode: 'IN',
    serverCode: 'IN-DC01',
    description: 'Bangalore TATA (Port 8443)',
    baseUrl: 'https://in-dc01.trainocate.com:8443/backend/',
    pingUrl: 'https://in-dc01.trainocate.com:8443/backend/empty.php',
    downloadUrl: 'https://in-dc01.trainocate.com:8443/backend/garbage.php',
    uploadUrl: 'https://in-dc01.trainocate.com:8443/backend/empty.php',
  },
  {
    id: 'in-dc02',
    name: 'India - INDC02',
    location: 'India (BLR_ACT)',
    countryCode: 'IN',
    serverCode: 'IN-DC02',
    description: 'Bangalore ACT (Port 8443)',
    baseUrl: 'https://in-dc02.trainocate.com:8443/backend/',
    pingUrl: 'https://in-dc02.trainocate.com:8443/backend/empty.php',
    downloadUrl: 'https://in-dc02.trainocate.com:8443/backend/garbage.php',
    uploadUrl: 'https://in-dc02.trainocate.com:8443/backend/empty.php',
  },
  {
    id: 'lk-dc01',
    name: 'Sri Lanka',
    location: 'Sri Lanka',
    countryCode: 'LK',
    serverCode: 'LK-DC01',
    description: 'Srilanka Region (Port 8443)',
    baseUrl: 'https://lk-dc01.trainocate.com:8443/backend/',
    pingUrl: 'https://lk-dc01.trainocate.com:8443/backend/empty.php',
    downloadUrl: 'https://lk-dc01.trainocate.com:8443/backend/garbage.php',
    uploadUrl: 'https://lk-dc01.trainocate.com:8443/backend/empty.php',
  },
  {
    id: 'sg-dc01',
    name: 'Singapore',
    location: 'Singapore',
    countryCode: 'SG',
    serverCode: 'SG-DC01',
    description: 'Singapore Region (Port 8443)',
    baseUrl: 'https://sg-dc01.trainocate.com:8443/backend/',
    pingUrl: 'https://sg-dc01.trainocate.com:8443/backend/empty.php',
    downloadUrl: 'https://sg-dc01.trainocate.com:8443/backend/garbage.php',
    uploadUrl: 'https://sg-dc01.trainocate.com:8443/backend/empty.php',
  },
];
