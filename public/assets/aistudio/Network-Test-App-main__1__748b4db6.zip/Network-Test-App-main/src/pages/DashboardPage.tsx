import React, { useState, useEffect, useRef } from 'react';
import { TEST_ENDPOINTS, TestEndpoint } from '../config/endpoints';
import {
  speedTestEngine,
  LiveMetrics,
  SpeedTestResult,
  TestStage,
} from '../services/speedTestEngine';
import { Header } from '../components/Header';
import { SpeedGauge } from '../components/SpeedGauge';
import { RegionResultSection, RegionState } from '../components/RegionResultSection';
import { EndpointConfigModal } from '../components/EndpointConfigModal';
import {
  Play,
  Square,
  AlertTriangle,
  RotateCcw,
  SlidersHorizontal,
  ShieldCheck,
  Zap,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  Activity,
  Globe2,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  // In-memory state for all four regions: IN-DC01, IN-DC02, LK-DC01, SG-DC01
  const [regionStates, setRegionStates] = useState<RegionState[]>(() =>
    TEST_ENDPOINTS.map((endpoint) => ({
      endpoint,
      status: 'waiting',
      stage: 'idle',
      liveMetrics: null,
      result: null,
      errorMessage: null,
    }))
  );

  // Active testing sequence states
  const [activeRegionIndex, setActiveRegionIndex] = useState<number | null>(null);
  const [isSequenceRunning, setIsSequenceRunning] = useState<boolean>(false);
  const [hasCompletedRun, setHasCompletedRun] = useState<boolean>(false);

  // Modal inspector
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);

  // Cancellation and abort tracking
  const isCancelledRef = useRef<boolean>(false);
  const activeIndexRef = useRef<number | null>(null);
  const testSectionRef = useRef<HTMLDivElement>(null);

  // Sync ref
  activeIndexRef.current = activeRegionIndex;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isCancelledRef.current = true;
      speedTestEngine.stopTest();
    };
  }, []);

  /**
   * One-click sequential execution across all four regions in order:
   * 1. IN-DC01 — India (https://in-dc01.trainocate.com:8443)
   * 2. IN-DC02 — India (https://in-dc02.trainocate.com:8443)
   * 3. LK-DC01 — Sri Lanka (https://lk-dc01.trainocate.com:8443)
   * 4. SG-DC01 — Singapore (https://sg-dc01.trainocate.com:8443)
   */
  const handleStartSequentialTest = async () => {
    if (isSequenceRunning) return;

    isCancelledRef.current = false;
    setIsSequenceRunning(true);
    setHasCompletedRun(false);

    // Reset all four regions' statuses/results when a new complete run starts
    setRegionStates(
      TEST_ENDPOINTS.map((endpoint) => ({
        endpoint,
        status: 'waiting',
        stage: 'idle',
        liveMetrics: null,
        result: null,
        errorMessage: null,
      }))
    );

    // Smooth scroll into focus
    testSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Controlled sequential loop with await
    for (let i = 0; i < TEST_ENDPOINTS.length; i++) {
      if (isCancelledRef.current) break;

      const currentEndpoint = TEST_ENDPOINTS[i];
      setActiveRegionIndex(i);

      // Set current region to 'testing'
      setRegionStates((prev) =>
        prev.map((region, idx) =>
          idx === i
            ? {
                ...region,
                status: 'testing',
                stage: 'ping',
                errorMessage: null,
                liveMetrics: {
                  stage: 'ping',
                  progressPercent: 2,
                  pingMs: null,
                  jitterMs: null,
                  currentDownloadMbps: null,
                  currentUploadMbps: null,
                  pingProgress: 5,
                  jitterProgress: 0,
                  downloadProgress: 0,
                  uploadProgress: 0,
                },
              }
            : region
        )
      );

      // Perform test directly against external server
      try {
        await speedTestEngine.startTest(currentEndpoint, {
          onProgress: (metrics) => {
            if (isCancelledRef.current) return;
            setRegionStates((prev) =>
              prev.map((region, idx) =>
                idx === i
                  ? {
                      ...region,
                      stage: metrics.stage,
                      liveMetrics: { ...metrics },
                    }
                  : region
              )
            );
          },
          onComplete: (result) => {
            if (isCancelledRef.current) return;
            setRegionStates((prev) =>
              prev.map((region, idx) =>
                idx === i
                  ? {
                      ...region,
                      status: 'completed',
                      stage: 'complete',
                      result,
                    }
                  : region
              )
            );
          },
          onError: (friendlyErrorMessage) => {
            if (isCancelledRef.current) return;
            // On failure, record failure state and continue automatically to next region
            setRegionStates((prev) =>
              prev.map((region, idx) =>
                idx === i
                  ? {
                      ...region,
                      status: 'failed',
                      stage: 'error',
                      errorMessage: friendlyErrorMessage,
                      liveMetrics: null,
                    }
                  : region
              )
            );
          },
          onCancelled: () => {
            // Handled when user presses Stop Test
          },
        });
      } catch (err: any) {
        if (isCancelledRef.current) break;
        setRegionStates((prev) =>
          prev.map((region, idx) =>
            idx === i
              ? {
                  ...region,
                  status: 'failed',
                  stage: 'error',
                  errorMessage:
                    err.message ||
                    'Direct browser connection failed due to CORS or network rejection.',
                  liveMetrics: null,
                }
              : region
          )
        );
      }

      if (isCancelledRef.current) break;

      // Small pause between regions for visual clarity
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    setIsSequenceRunning(false);
    setActiveRegionIndex(null);

    if (!isCancelledRef.current) {
      setHasCompletedRun(true);
    }
  };

  /**
   * Stop test button: aborts active request and stops the remaining sequence
   */
  const handleStopTest = () => {
    isCancelledRef.current = true;
    speedTestEngine.stopTest();
    setIsSequenceRunning(false);

    const currentIdx = activeIndexRef.current;
    if (currentIdx !== null) {
      setRegionStates((prev) =>
        prev.map((region, idx) =>
          idx === currentIdx && region.status === 'testing'
            ? {
                ...region,
                status: 'waiting',
                stage: 'idle',
                liveMetrics: null,
              }
            : region
        )
      );
    }

    setActiveRegionIndex(null);
  };

  // Derive active region's metrics for top gauge
  const activeRegion = activeRegionIndex !== null ? regionStates[activeRegionIndex] : null;
  const activeMetrics = activeRegion?.liveMetrics || null;
  const activeStage: TestStage = activeRegion?.stage || (hasCompletedRun ? 'complete' : 'idle');

  // Overall summary statistics
  const completedCount = regionStates.filter((r) => r.status === 'completed').length;
  const failedCount = regionStates.filter((r) => r.status === 'failed').length;
  const waitingCount = regionStates.filter((r) => r.status === 'waiting').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Header */}
      <Header onOpenConfig={() => setIsConfigModalOpen(true)} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-8">
        {/* Welcome Section & System Architecture Overview */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 backdrop-blur-xl">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
                Sequential Network Benchmarking
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-400">One-Click Multi-Region Pipeline</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Real 4-Region Speed Test
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              One-click direct browser benchmarking executed sequentially across all four dedicated LibreSpeed
              servers: <strong>IN-DC01 (India)</strong> → <strong>IN-DC02 (India)</strong> →{' '}
              <strong>LK-DC01 (Sri Lanka)</strong> → <strong>SG-DC01 (Singapore)</strong>.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <button
              onClick={() => setIsConfigModalOpen(true)}
              type="button"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Endpoints & Architecture</span>
            </button>
          </div>
        </div>

        {/* Section 1: Main Execution Control Bar */}
        <section
          ref={testSectionRef}
          className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-xl shadow-2xl relative overflow-hidden"
        >
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  Sequential Pipeline
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {isSequenceRunning
                    ? `Testing Region ${(activeRegionIndex ?? 0) + 1} of 4`
                    : hasCompletedRun
                    ? 'Sequence Finished'
                    : 'Ready to Run'}
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {isSequenceRunning && activeRegion
                  ? `Benchmarking ${activeRegion.endpoint.serverCode} (${activeRegion.endpoint.location})`
                  : hasCompletedRun
                  ? 'All 4 Regional Tests Processed'
                  : 'Start Sequential 4-Region Benchmark'}
              </h2>
              <p className="text-xs text-slate-400">
                {isSequenceRunning
                  ? 'Tests run sequentially in strict order. Completed region results stay visible.'
                  : 'Click Start Speed Test to run all four regions sequentially with zero simulated data.'}
              </p>
            </div>

            {/* Test Action Controls */}
            <div className="flex items-center gap-3">
              {isSequenceRunning ? (
                <button
                  onClick={handleStopTest}
                  type="button"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl font-bold text-base bg-red-600 hover:bg-red-500 text-white shadow-xl shadow-red-600/30 transition-all duration-200 cursor-pointer active:scale-95"
                >
                  <Square className="w-4 h-4 fill-white" />
                  <span>Stop Test</span>
                </button>
              ) : (
                <button
                  onClick={handleStartSequentialTest}
                  type="button"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl font-bold text-base bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 text-white shadow-xl shadow-cyan-500/25 transition-all duration-200 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                >
                  {hasCompletedRun ? (
                    <>
                      <RotateCcw className="w-5 h-5" />
                      <span>Run All Tests Again</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-white" />
                      <span>Start Speed Test</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Sequence Pipeline Visual Steps (1 -> 2 -> 3 -> 4) */}
          <div className="mt-6 pt-6 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {regionStates.map((reg, idx) => {
              const isCurrent = activeRegionIndex === idx;
              return (
                <div
                  key={reg.endpoint.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-cyan-950/30 border-cyan-500/60 ring-1 ring-cyan-500/40 shadow-lg shadow-cyan-500/10'
                      : reg.status === 'completed'
                      ? 'bg-slate-900/90 border-emerald-500/40'
                      : reg.status === 'failed'
                      ? 'bg-slate-900/90 border-rose-500/40'
                      : 'bg-slate-950/60 border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono text-slate-400 font-semibold uppercase tracking-wider">
                      Step 0{idx + 1}
                    </span>
                    {reg.status === 'waiting' && (
                      <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" /> Waiting
                      </span>
                    )}
                    {reg.status === 'testing' && (
                      <span className="text-[10px] font-mono text-cyan-300 font-bold flex items-center gap-1 animate-pulse">
                        <Activity className="w-2.5 h-2.5 text-cyan-400 animate-spin" /> Testing
                      </span>
                    )}
                    {reg.status === 'completed' && (
                      <span className="text-[10px] font-mono text-emerald-300 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" /> Completed
                      </span>
                    )}
                    {reg.status === 'failed' && (
                      <span className="text-[10px] font-mono text-rose-300 font-semibold flex items-center gap-1">
                        <XCircle className="w-2.5 h-2.5 text-rose-400" /> Failed
                      </span>
                    )}
                  </div>
                  <div className="font-bold text-white text-sm flex items-center justify-between">
                    <span>{reg.endpoint.serverCode}</span>
                    <span className="text-xs font-normal text-slate-400">{reg.endpoint.countryCode}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">{reg.endpoint.name}</div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Section 2: Active Benchmark Gauge & Live Diagnostic Spotlight */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Active Speed Gauge (7 columns) */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            <SpeedGauge
              stage={activeStage}
              currentDownloadMbps={activeMetrics?.currentDownloadMbps ?? null}
              currentUploadMbps={activeMetrics?.currentUploadMbps ?? null}
              pingMs={activeMetrics?.pingMs ?? null}
              jitterMs={activeMetrics?.jitterMs ?? null}
              progressPercent={activeMetrics?.progressPercent ?? 0}
            />
          </div>

          {/* Active Stream Stage & Sequence Diagnostic Panel (5 columns) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-xl flex-1 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Active Probe Monitor
                  </h3>
                  <span className="text-xs font-mono text-slate-400">
                    {activeRegion ? activeRegion.endpoint.serverCode : 'Idle'}
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Ping status item */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">1. Ping (Latency Probe)</span>
                      <span className="font-mono text-amber-300">
                        {activeMetrics?.pingMs !== null && activeMetrics?.pingMs !== undefined
                          ? `${activeMetrics.pingMs.toFixed(1)} ms`
                          : '--'}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-400 transition-all duration-200"
                        style={{ width: `${activeMetrics?.pingProgress || 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Jitter status item */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">2. Jitter (Packet Variation)</span>
                      <span className="font-mono text-sky-300">
                        {activeMetrics?.jitterMs !== null && activeMetrics?.jitterMs !== undefined
                          ? `${activeMetrics.jitterMs.toFixed(2)} ms`
                          : '--'}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-sky-400 transition-all duration-200"
                        style={{ width: `${activeMetrics?.jitterProgress || 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Download status item */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">3. Download Stream</span>
                      <span className="font-mono text-cyan-300">
                        {activeMetrics?.currentDownloadMbps !== null &&
                        activeMetrics?.currentDownloadMbps !== undefined
                          ? `${activeMetrics.currentDownloadMbps.toFixed(2)} Mbps`
                          : '--'}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-400 transition-all duration-200"
                        style={{ width: `${activeMetrics?.downloadProgress || 0}%` }}
                      />
                    </div>
                  </div>

                  {/* Upload status item */}
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">4. Upload Stream</span>
                      <span className="font-mono text-indigo-300">
                        {activeMetrics?.currentUploadMbps !== null &&
                        activeMetrics?.currentUploadMbps !== undefined
                          ? `${activeMetrics.currentUploadMbps.toFixed(2)} Mbps`
                          : '--'}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-400 transition-all duration-200"
                        style={{ width: `${activeMetrics?.uploadProgress || 0}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Progress Summary Footer */}
              <div className="pt-4 border-t border-slate-800/80 mt-6 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Sequential single-stream flow</span>
                </div>
                <span>Strict zero-logging</span>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Overall Completion Banner (Requirement 9) */}
        {hasCompletedRun && !isSequenceRunning && (
          <section className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/40 border border-cyan-500/30 shadow-2xl animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    Sequential Speed Test Complete
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      4 of 4 Processed
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    All four regional LibreSpeed endpoints have been tested sequentially in memory. Review the
                    individual results below.
                  </p>
                  <div className="flex flex-wrap items-center gap-4 mt-3 text-xs font-mono">
                    <span className="text-emerald-400">
                      ✓ Completed: <strong>{completedCount}</strong>
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-rose-400">
                      ✕ Connection Blocked / Failed: <strong>{failedCount}</strong>
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleStartSequentialTest}
                type="button"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs bg-cyan-600 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-600/20 transition-all cursor-pointer self-start sm:self-auto hover:scale-105"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Run Sequence Again
              </button>
            </div>
          </section>
        )}

        {/* Section 4: Four Separate Result Sections (Compact 2x2 Grid on Desktop) */}
        <section className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Trainocate DC Speed Test Results
              </h2>
              <p className="text-xs text-slate-400">
                Four dedicated sections for IN-DC01, IN-DC02, LK-DC01, and SG-DC01 in a compact 2×2 grid.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {completedCount} Completed • {failedCount} Failed • {waitingCount} Waiting
            </span>
          </div>

          {/* Render the four separate sections in a compact 2x2 grid on desktop */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
            {regionStates.map((region, index) => (
              <RegionResultSection
                key={region.endpoint.id}
                region={region}
                index={index}
                isActive={activeRegionIndex === index}
              />
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>Speed Test Demo App • Direct Browser-to-Server Testing</div>
          <div className="text-slate-600 font-mono">
            Sequential Order: IN-DC01 → IN-DC02 → LK-DC01 → SG-DC01
          </div>
        </div>
      </footer>

      {/* Endpoint Diagnostics Modal */}
      <EndpointConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        selectedEndpoint={activeRegion?.endpoint || TEST_ENDPOINTS[0]}
      />
    </div>
  );
};
